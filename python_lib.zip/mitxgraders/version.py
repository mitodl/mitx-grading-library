"""
MITx Grading Library
Version number
"""

__version__ = "3.0.0"
