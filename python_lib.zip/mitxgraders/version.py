"""
MITx Gradling Library
Version number
"""

__version__ = "1.0.3"
