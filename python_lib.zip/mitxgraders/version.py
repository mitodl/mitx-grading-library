"""
MITx Gradling Library
Version number
"""

__version__ = "1.1.1"
