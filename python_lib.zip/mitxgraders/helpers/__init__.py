from mitxgraders.helpers.specify_domain import specify_domain

# Set the objects to be imported from this module
__all__ = [
    "specify_domain"
]
