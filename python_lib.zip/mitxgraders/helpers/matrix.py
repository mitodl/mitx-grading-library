import numpy as np
from numbers import Number
from mitxgraders.baseclasses import StudentFacingError

class MatrixError(StudentFacingError):
    """
    Thrown by Matrix when anticipated errors are made.
    """

def is_scalar_zero(value):
    """
    Tests whether a value is the scalar number 0.

    >>> map(is_scalar_zero, [0, 0.0, 0j])
    [True, True, True]
    >>> is_scalar_zero(np.matrix([0, 0, 0]))
    False
    """
    return isinstance(value, Number) and value == 0

def is_square(array):
    return array.shape[0] == array.shape[1]

class Matrix(np.matrix):
    """
    A modification of numpy's matrix class that restricts some operations and
    cleans error messages.

    Differences from numpy.matrix:
    ==============================
        - cannot add nonzero scalars to matrices
        - supports multiplication with a universal identity irrespective of own shape
        - supports addition/subtraction with a universal identity if square
        - can raise to float powers if float is_integer, e.g., A^2.0
        - Throws MatrixError instances when anticipated errors are made.
    """

    def __add__(self, other):
        if is_scalar_zero(other):
            return self
        elif isinstance(other, Number):
            raise MatrixError("Cannot add/subtract scalar numbers to a matrix.")
        elif isinstance(other, IdentityMultiple):
            if is_square(self):
                return self.__add__(other.as_matrix(self.shape[0]))
            raise MatrixError("Cannot add/subtract multiples of the identity "
                                          "matrix to a non-square matrix")
        elif isinstance(other, Matrix):
            if self.shape == other.shape:
                return super(Matrix, self).__add__(other)
            raise MatrixError("Cannot add/subtract matrices of shapes "
                                          "{0} and {1}".format(self.shape, other.shape))

        raise TypeError("Cannot add/subtract object of {othertype} to a matrix.".format(
            othertype=type(other)))

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        return self.__add__(-1*other)

    def __rsub__(self, other):
        return (-self).__add__(other) # pylint: disable=invalid-unary-operand-type

    def __mul__(self, other):
        if isinstance(other, Matrix) and self.shape[1] != other.shape[0]:
            raise MatrixError("Cannot calculate product of matrices with shapes "
                                          "{0} and {1}".format(self.shape, other.shape))
        elif isinstance(other, IdentityMultiple):
            other = other.value
        return super(Matrix, self).__mul__(other)

    def __rmul__(self, other):
        if isinstance(other, IdentityMultiple):
            other = other.value
        return super(Matrix, self).__rmul__(other)

    def __pow__(self, other):
        if not is_square(self):
            raise MatrixError("Cannot raise a non-square matrix to powers.")
        elif isinstance(other, int):
            return super(Matrix, self).__pow__(other)
        elif isinstance(other, float) and other.is_integer():
            return super(Matrix, self).__pow__(int(other))
        elif isinstance(other, Number):
            raise MatrixError("Cannot raise matrix to non-integer powers")
        raise TypeError("Cannot raise matrix to power of type {othertype}".format(
            othertype=type(other)))

class IdentityMultiple(object):
    """
    Represents a multiple of the identity matrix.

    Instantiation:
    ==============

    Instantiate with a single value:
    >>> IdentityMultiple(5)
    5*Identity

    If instantiated with 0, the number 0 is returned:
    >>> IdentityMultiple(0) == 0
    True

    Comparisons:
    ============
    >>> IdentityMultiple(5) == IdentityMultiple(5)
    True
    >>> IdentityMultiple(5) == IdentityMultiple(3)
    False
    >>> IdentityMultiple(5) == 5
    False

    Unary Operations:
    =================
    They work:
    >>> +IdentityMultiple(5)
    5*Identity
    >>> -IdentityMultiple(5)
    -5*Identity

    Binary Operations:
    ==================
    When IdentityMultiple is involved in any binary operation, it delegates
    calculation to the other operand except in a few special cases, illustrated
    below.

    >>> import random
    >>> a, b = random.uniform(-10, 10), random.uniform(-10, 10)
    >>> I = IdentityMultiple

    Addition with zero:
    >>> assert I(a) + 0 == 0 + I(a) == I(a)

    Subtraction with zero:
    >>> assert I(a) - 0 == I(a)
    >>> assert 0 - I(a) == -I(a)

    Multiplication with scalars:
    >>> assert b*I(a) == I(a)*b == I(a*b)

    Division with scalars:
    >>> assert I(a)/b == I(a/b)
    >>> b/I(a)
    Traceback (most recent call last):
    TypeError: unsupported operand type(s) for /: 'float' and 'IdentityMultiple'

    Scalar powers:
    >>> c = random.uniform(1, 10) # make sure the base is positive
    >>> assert I(c)**a == I(c**a)

    Addition, Subtraction, and Multiplication with other IdentityMultiples:
    >>> assert I(a) + I(b) == I(a + b)
    >>> assert I(a) - I(b) == I(a - b)
    >>> assert I(a) * I(b) == I(a*b)

    Since I(0)==0, sums and differences might be scalar 0:
    >>> assert I(a) - I(a) == 0
    """
    def __new__(cls, value):
        if is_scalar_zero(value):
            return 0
        return super(IdentityMultiple, cls).__new__(cls, value)

    def as_matrix(self, n):
        """
        Returns a multiple of the n by n identity matrix.

        >>> S = IdentityMultiple(4)
        >>> S_mat2 = S.as_matrix(2)
        >>> S_mat2.tolist()
        [[4.0, 0.0], [0.0, 4.0]]
        >>> isinstance(S_mat2, Matrix)
        True
        """
        elements = (self.value*np.identity(n))
        return Matrix(elements)

    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return "{value}*Identity".format(value=self.value)

    def __eq__(self, other):
        if isinstance(other, IdentityMultiple):
            return self.value == other.value
        return False

    def __pos__(self):
        return self
    def __neg__(self):
        return IdentityMultiple(-self.value)

    def __add__(self, other):
        if is_scalar_zero(other):
            return self
        elif isinstance(other, IdentityMultiple):
            return IdentityMultiple(self.value + other.value)
        return other.__radd__(self)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        if is_scalar_zero(other):
            return self
        elif isinstance(other, IdentityMultiple):
            return IdentityMultiple(self.value - other.value)
        return other.__rsub__(self)

    def __rsub__(self, other):
        return (-self).__add__(other)

    def __mul__(self, other):
        if isinstance(other, Number):
            return IdentityMultiple(self.value*other)
        elif isinstance(other, IdentityMultiple):
            return IdentityMultiple(self.value*other.value)
        return other.__rmul__(self)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __div__(self, other):
        if isinstance(other, Number):
            return IdentityMultiple(self.value/other)
        return other.__rdiv__(self)

    def __pow__(self, other):
        if isinstance(other, Number):
            return IdentityMultiple(self.value**other)
        return other.__rpow__(self)
