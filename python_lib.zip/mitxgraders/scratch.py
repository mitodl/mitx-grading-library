from sampling import RealInterval
